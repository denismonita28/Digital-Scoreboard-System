----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/12/2025
-- Design Name: Scoreboard
-- Module Name: Scoreboard - Behavioral
-- Description: Modul care gestionează scorul pentru două echipe folosind patru
--              butoane: increment/decrement pentru fiecare echipă. Scorul este 
--              afișat pe 4 digits cu 7 segmente.
-- 
----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity score is
    Port (
        rst1    : in STD_LOGIC;                     -- Semnal de reset extern (buton)
        clk     : in STD_LOGIC;                     -- Semnal de ceas
        button  : in STD_LOGIC_VECTOR (0 to 3);     -- Butoane pentru control scor
        seg     : out STD_LOGIC_VECTOR (0 to 6);    -- Segmentele pentru afișaj 7 segmente
        dp      : out STD_LOGIC;                    -- Punctul zecimal (unused)
        an      : out STD_LOGIC_VECTOR (3 downto 0) -- Selectarea digit-urilor pe afișaj
    );
end score;

architecture Behavioral of score is

    -- Definim stările finite ale automatului
    type states is (
        start,
        press,
        count_up_team1,
        count_down_team1,
        count_up_team2,
        count_down_team2
    );

    signal current_state, next_state : states;

    -- Variabilă folosită în procesul de selectare a stărilor
    signal i : integer range 0 to 3;

    -- Divider pentru a crea un semnal de "ceas lent" (~0.1 sec la 50MHz)
    constant n : integer := 5*10**6;
    signal divider : integer := 0;
    signal ce : std_logic := '0';

    -- Semnale pentru componenta de debounce și reset
    signal rst : std_logic;
    signal scorafisat : std_logic_vector(15 downto 0); -- Format: z1u1z2u2

    -- Componenta de afișaj 7 segmente
    component Scoreboard_file2 is
        Port (
            clk     : in STD_LOGIC;
            Din     : in STD_LOGIC_VECTOR (15 downto 0);
            an      : out STD_LOGIC_VECTOR (3 downto 0);
            seg     : out STD_LOGIC_VECTOR (0 to 6);
            dp_in   : in STD_LOGIC_VECTOR (3 downto 0);
            dp_out  : out STD_LOGIC;
            rst     : in STD_LOGIC
        );
    end component;

    -- Componenta debounce pentru reset
    component deBounce1 is
        port (
            clk        : in std_logic;
            rst        : in std_logic;
            button_in  : in std_logic;
            pulse_out  : out std_logic
        );
    end component;

begin

    -- Debounce pentru semnalul de reset
    RESET: deBounce1 port map (
        clk => clk,
        rst => '0',
        button_in => rst1,
        pulse_out => rst
    );

    -- Proces pentru generarea semnalului de ceas "ce"
    process (rst, clk)
    begin
        if rst = '1' then
            divider <= 0;
            ce <= '0';
        elsif rising_edge(clk) then
            if divider = n - 1 then
                divider <= 0;
                ce <= '1';
            else
                divider <= divider + 1;
                ce <= '0';
            end if;
        end if;
    end process;

    -- FSM: schimbarea stării curente
    ff : process(rst, clk)
    begin
        if rst = '1' then
            current_state <= start;
        elsif rising_edge(clk) then
            current_state <= next_state;
        end if;
    end process;

    -- FSM: logica de tranziție între stări
    clc : process (current_state, button, i)
    begin
        case current_state is
            when start =>
                next_state <= press;

            when press =>
                if button(0) = '1' then
                    next_state <= count_up_team1;
                elsif button(1) = '1' then
                    next_state <= count_down_team1;
                elsif button(2) = '1' then
                    next_state <= count_up_team2;
                elsif button(3) = '1' then
                    next_state <= count_down_team2;
                else
                    next_state <= press;
                end if;

            when count_up_team1 | count_down_team1 |
                 count_up_team2 | count_down_team2 =>
                next_state <= start;

            when others =>
                next_state <= start;
        end case;
    end process;

    -- Proces pentru gestionarea scorului și generarea valorii scorafisat
generare_score: process(clk, rst)
    variable z1, u1, z2, u2 : integer range 0 to 9 := 0; -- zecimale și unități pentru fiecare echipă
begin
    if rst = '1' then
        -- Resetare scor la 0 pentru ambele echipe
        z1 := 0; u1 := 0;
        z2 := 0; u2 := 0;
    elsif rising_edge(clk) then
        if ce = '1' then

            -- Increment echipa 1
            if current_state = count_up_team1 then
                if u1 = 9 then
                    u1 := 0;
                    if z1 < 9 then
                        z1 := z1 + 1;
                    end if;
                else
                    u1 := u1 + 1;
                end if;
            end if;

            -- Decrement echipa 1 (doar dacă scorul > 0)
            if current_state = count_down_team1 then
                if (z1 > 0) or (u1 > 0) then
                    if u1 = 0 then
                        -- Unitățile sunt 0, decrementăm zecimalele dacă sunt > 0 și unitățile devin 9
                        if z1 > 0 then
                            z1 := z1 - 1;
                        end if;
                        u1 := 9;
                    else
                        -- Unitățile sunt > 0, doar decrementăm unitățile
                        u1 := u1 - 1;
                    end if;
                end if;
                -- Dacă scorul este deja 0, nu facem nimic (nu scădem sub 0)
            end if;

            -- Increment echipa 2
            if current_state = count_up_team2 then
                if u2 = 9 then
                    u2 := 0;
                    if z2 < 9 then
                        z2 := z2 + 1;
                    end if;
                else
                    u2 := u2 + 1;
                end if;
            end if;

            -- Decrement echipa 2 (doar dacă scorul > 0)
            if current_state = count_down_team2 then
                if (z2 > 0) or (u2 > 0) then
                    if u2 = 0 then
                        -- Unitățile sunt 0, decrementăm zecimalele dacă sunt > 0 și unitățile devin 9
                        if z2 > 0 then
                            z2 := z2 - 1;
                        end if;
                        u2 := 9;
                    else
                        -- Unitățile sunt > 0, doar decrementăm unitățile
                        u2 := u2 - 1;
                    end if;
                end if;
                -- Dacă scorul este deja 0, nu facem nimic (nu scădem sub 0)
            end if;

            -- Resetare automată dacă scorul ajunge la 99 (toate cifrele 9)
            if (z1 = 9 and u1 = 9) then
                z1 := 0; u1 := 0;
            end if;

            if (z2 = 9 and u2 = 9) then
                z2 := 0; u2 := 0;
            end if;

            -- Combinarea valorilor în scorafisat: [z1][u1][z2][u2]
            scorafisat <= std_logic_vector(to_unsigned(z1, 4)) &
                          std_logic_vector(to_unsigned(u1, 4)) &
                          std_logic_vector(to_unsigned(z2, 4)) &
                          std_logic_vector(to_unsigned(u2, 4));
        end if;
    end if;
end process;


    -- Instanțierea afișajului 7 segmente
    display : Scoreboard_file2 port map (
        clk     => clk,
        Din     => scorafisat,
        an      => an,
        seg     => seg,
        dp_in   => (others => '0'),
        dp_out  => dp,
        rst     => rst
    );

end Behavioral;
