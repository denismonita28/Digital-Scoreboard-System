----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/12/2025 11:12:00 PM
-- Design Name: 
-- Module Name: Scoreboard_file2 - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity Scoreboard_file2 is
    Port ( clk : in STD_LOGIC; -- Intrare semnal ceas (clock) de 100MHz
           Din : in STD_LOGIC_VECTOR (15 downto 0); -- Date binare de 16 biți pentru cele 4 afișaje
           an : out STD_LOGIC_VECTOR (3 downto 0); -- Ieșiri anode pentru selectarea afișajelor (de la 3 la 0)
           seg : out STD_LOGIC_VECTOR (0 to 6); -- Ieșiri catodice pentru selectarea segmentelor LED-urilor pe fiecare afișaj
           dp_in : in STD_LOGIC_VECTOR (3 downto 0); -- Intrare pentru punctul zecimal pentru fiecare afișaj
           dp_out : out STD_LOGIC; -- Punctul zecimal selectat care va fi trimis către catode
           rst : in STD_LOGIC); -- Reset global
end Scoreboard_file2;

architecture Behavioral of Scoreboard_file2 is

-- Semnale interne
signal clk1kHz : STD_LOGIC; -- Semnal ceas de 1kHz pentru multiplexarea afișajelor
signal state : STD_LOGIC_VECTOR(16 downto 0); -- Stare pentru contorul de 1kHz
signal addr : STD_LOGIC_VECTOR(1 downto 0); -- Adresa curentă pentru selecția afișajelor
signal cseg : STD_LOGIC_VECTOR(3 downto 0); -- Segmente pentru afișajul curent

begin

-- Divizor de frecvență pentru generarea unui semnal de 1kHz pentru multiplexarea afișajelor
-- Contorul numără de la 0 la 99999 pentru a produce un semnal de 1kHz la ieșire
div1kHz: process(clk, rst)
begin
   if rst = '1' then 
        state <= '0' & X"0000"; -- Resetare starea contorului
   else
     if rising_edge(clk) then
        if state = '1' & X"869F" then -- Dacă contorul ajunge la 99999
            state <= '0' & X"0000"; -- Resetare contor
        else
            state <= state+1; -- Incrementare contor
        end if;
     end if;
   end if;         
end process;

-- Semnal de ieșire de 1kHz pentru multiplexarea afișajelor
clk1Khz <= state(16); -- Se preia cel mai semnificativ bit al stării contorului

-- Contor de 2 biți care generează 4 adrese pentru multiplexarea afișajelor
counter_2bits: process(clk1kHz)
begin
  if rising_edge(clk1kHz) then       
           addr <= addr+1; -- Incrementarea adresei pentru afișajul curent
  end if;   
end process;

-- Decoder 2 la 4 folosit pentru a selecta un afișaj din cele 4, în funcție de adresa curentă
-- Anodele sunt active pe nivel scăzut, deci trebuie să generăm '0' pentru a activa afișajul
dcd3_8: process(addr)
begin
  case addr is
      when "00" =>  an <= "0111"; -- Selectarea afișajului 3
      when "01" =>  an <= "1011"; -- Selectarea afișajului 2
      when "10" =>  an <= "1101"; -- Selectarea afișajului 1
      when "11" =>  an <= "1110"; -- Selectarea afișajului 0
      when others => an <= "1111"; -- Dacă adresa nu este valabilă, nu selectăm niciun afișaj
   end case; 
end process;

-- Multiplexor cu 4 intrări pentru a selecta datele care vor fi trimise la afișajul curent
-- Sincronizat cu adresa generată și cu activarea afișajului prin anode
data_mux4: process(addr, Din, dp_in)
begin
  case addr is
      when "00" =>  cseg <= Din(15 downto 12); -- Trimiterea primelor 4 biți la afișajul 3
                    dp_out <= not dp_in(3); -- Activarea punctului zecimal pe afișajul 3
      when "01" =>  cseg <= Din(11 downto 8); -- Trimiterea următorilor 4 biți la afișajul 2
                    dp_out <= not dp_in(2); -- Activarea punctului zecimal pe afișajul 2
      when "10" =>  cseg <= Din(7 downto 4);  -- Trimiterea altor 4 biți la afișajul 1
                    dp_out <= not dp_in(1); -- Activarea punctului zecimal pe afișajul 1
      when "11" =>  cseg <= Din(3 downto 0); -- Trimiterea ultimilor 4 biți la afișajul 0
                    dp_out <= not dp_in(0); -- Activarea punctului zecimal pe afișajul 0
      when others => cseg <= "XXXX"; -- Dacă adresa nu este valabilă, nu trimitem date
                     dp_out <= 'X'; -- Dacă adresa nu este valabilă, nu activăm punctul zecimal
   end case; 
end process;

-- Decoder binar la 7 segmente pentru a converti valoarea binară într-un format care poate fi afisat pe LED-urile de pe fiecare afișaj
-- Segmentul este activ pe nivel scăzut, deci trebuie să trimitem '0' pentru a aprinde un segment
dcd7seg:process(cseg)
begin
  case cseg is
      when "0000" =>  seg <= "0000001"; -- 0
      when "0001" =>  seg <= "1001111"; -- 1
      when "0010" =>  seg <= "0010010"; -- 2
      when "0011" =>  seg <= "0000110"; -- 3
      when "0100" =>  seg <= "1001100"; -- 4
      when "0101" =>  seg <= "0100100"; -- 5
      when "0110" =>  seg <= "0100000"; -- 6
      when "0111" =>  seg <= "0001111"; -- 7
      when "1000" =>  seg <= "0000000"; -- 8
      when "1001" =>  seg <= "0000100"; -- 9
      when "1010" =>  seg <= "0000010"; -- A
      when "1011" =>  seg <= "1100000"; -- B
      when "1100" =>  seg <= "0110001"; -- C
      when "1101" =>  seg <= "1000010"; -- D
      when "1110" =>  seg <= "0110000"; -- E
      when "1111" =>  seg <= "0111000"; -- F
      when others => seg <= "XXXXXXX"; -- Dacă valoarea nu este valabilă, nu aprindem niciun segment
  end case; 
end process;

end Behavioral;
