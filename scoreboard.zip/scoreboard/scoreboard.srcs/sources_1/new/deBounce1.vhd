library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity deBounce1 is
    port(   
        clk        : in std_logic;         -- Ceasul principal (100 MHz)
        rst        : in std_logic;         -- Reset asincron
        button_in  : in std_logic;         -- Semnal brut de la buton
        pulse_out  : out std_logic         -- Puls de ieșire, generat la 5 apăsări valide
    );
end deBounce1;

architecture Behavioral of deBounce1 is

    -- Parametru debounce (~20 ms la 100 MHz = 2 milioane de cicluri)
    constant COUNT_MAX : integer := 2000000;

    -- Semnale interne
    type state_type is (idle, wait_release);
    signal state : state_type := idle;

    signal count       : integer := 0;         -- Contor debounce
    signal button_sync : std_logic := '0';     -- Semnal sincronizat curățat
    signal prev_button : std_logic := '0';     -- Pentru detecție de front
    signal press_count : integer range 0 to 5 := 0;  -- Contor apăsări

begin

    process(clk, rst)
    begin
        if rst = '1' then
            count       <= 0;
            state       <= idle;
            button_sync <= '0';
            prev_button <= '0';
            press_count <= 0;
            pulse_out   <= '0';

        elsif rising_edge(clk) then
            case state is
                when idle =>
                    if button_in = '1' then
                        -- Start debounce
                        count <= 1;
                        state <= wait_release;
                    end if;
                    pulse_out <= '0';

                when wait_release =>
                    if button_in = '1' then
                        if count < COUNT_MAX then
                            count <= count + 1;
                        else
                            -- Debounce valid: front de apăsare
                            if prev_button = '0' then
                                press_count <= press_count + 1;
                                if press_count = 4 then  -- A 5-a apăsare
                                    pulse_out <= '1';
                                    press_count <= 0;
                                else
                                    pulse_out <= '0';
                                end if;
                            end if;
                            prev_button <= '1';  -- Buton menținut apăsat
                        end if;
                    else
                        -- Buton eliberat
                        count <= 0;
                        state <= idle;
                        prev_button <= '0';
                    end if;
            end case;
        end if;
    end process;

end Behavioral;
